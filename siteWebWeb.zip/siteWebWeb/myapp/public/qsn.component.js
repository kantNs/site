/* globals Vue */
;(function () {
  'use strict'

  const template = `
<section id="qsn">
  <h1>QSN</h1>
  <p>Mon super texte</p>
</section>
  `

  Vue.component('qsn', {
    template: template
  })
})()